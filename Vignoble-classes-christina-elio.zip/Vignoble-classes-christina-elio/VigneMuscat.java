//SOUAIBY Christina
//SAMAHA Elio

public class VigneMuscat extends Vigne{
  // Constructeurs
  public VigneMuscat(){
    super("Vigne Muscat");
  }
}