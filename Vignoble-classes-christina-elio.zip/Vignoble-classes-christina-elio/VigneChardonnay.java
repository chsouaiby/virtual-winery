//SOUAIBY Christina
//SAMAHA Elio

public class VigneChardonnay extends Vigne{
  // Constructeurs
  public VigneChardonnay(){
    super("Vigne Chardonnay");
  }
}