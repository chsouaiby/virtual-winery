//SOUAIBY Christina
//SAMAHA Elio

public class ListeVideException extends Exception{
  public ListeVideException(){
    super("Liste d'agent ou liste de ressource vide");
  }
}