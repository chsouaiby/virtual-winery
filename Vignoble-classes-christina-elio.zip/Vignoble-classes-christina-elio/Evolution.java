//SOUAIBY Christina
//SAMAHA Elio

public interface Evolution{
  // La quantité de raisins sur les vignes  augmente au fil des saisons, mais diminue en hiver
  public void croissance();
}