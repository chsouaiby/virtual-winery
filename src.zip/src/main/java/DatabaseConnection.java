import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    /* This class is used to connect our Interface to our Database. Check the README.txt if needed */

    public static Connection getConnection() throws SQLException {

        // connection parameters
        String url = "jdbc:mysql://localhost:3306/Winery"; 
        String user = "root";
        String password = "root"; 

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load the driver 
            Connection connection = DriverManager.getConnection(url, user, password);
            return connection;
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL Driver not found!");
            e.printStackTrace();
            throw new SQLException("Error connecting to database", e); 
        } catch (SQLException e) {
            System.err.println("Database connection failed!");
            e.printStackTrace();
            throw e; 
        }
    }
}