import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public abstract class Product {

    /* This abstract class serves as a base for different kinds of product.
     So far this project only handles wines, so most methods are redefined in the Wine class but this could be easily adaptable  */ 

    // ATTRIBUTES ----------------------------------------------------------------

    protected int id;
    protected String name;
    protected double price;
    protected int stock;

    // CONSTRUCTORS ---------------------------------------------------------------

    public Product() {} // Needed for database loading

    public Product(int id, String name, double price, int stock) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public Product(String name, double price, int stock) {
        this(0, name, price, stock);
    }

    // GETTERS + SETTERS ------------------------------------------------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    // METHODS ---------------------------------------------------------------

    public abstract void delete() throws SQLException;

    public abstract void saveToDatabase() throws SQLException; // Abstract method

    public abstract List<? extends Product> loadAllProducts(Connection connection) throws SQLException;
    public abstract void updateStock(int newStock) throws SQLException;

    @Override
    public String toString() {
        return name + " - Price: " + price + " EUR";
    }
}