import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

public class UserInterface extends JFrame {

    /*UserInterface handles the interactions of the customers with the app and the actions they can perform
     like search, filter products, make and update their cart and of course place an order and checkout. 

     Check the user.pdf document for more details on how this interface work*/ 

    // ATTRIBUTES -----------------------------------------------------------------
    
    private Catalog catalog;
    private Map<Product, Integer> cart = new HashMap<>();
    private double totalAmount = 0.0;
    private JLabel totalLabel;
    private JPanel cartPanel;
    private JPanel productPanel;
    private JTextField searchField;
    private JPanel typePanel;
    private JPanel regionPanel;
    private JPanel agePanel;
    private Set<String> availableTypes;
    private Set<String> availableRegions;
    private Set<Integer> availableAges;
    private JPanel cartItemsPanel;
    private JPanel cartFooterPanel;

    // CONSTRUCTORS -----------------------------------------------------------------

    public UserInterface() { //putting all the functionalities together with a simple, easy to use, design
        catalog = new Catalog();
        try {
            catalog.loadProductsFromDatabase();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading products: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            System.exit(1);
        }

        // filters on the products
        availableTypes = catalog.search("").stream().filter(p -> p instanceof Wine).map(p -> ((Wine) p).getWineType()).collect(Collectors.toSet());
        availableRegions = catalog.search("").stream().filter(p -> p instanceof Wine).map(p -> ((Wine) p).getRegion()).collect(Collectors.toSet());
        availableAges = catalog.search("").stream().filter(p -> p instanceof Wine).map(p -> ((Wine) p).getAge()).collect(Collectors.toSet());

        setTitle("Wine Haven");
        setSize(1500, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(128, 0, 0));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(new Color(128, 0, 0));

        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBackground(new Color(128, 0, 0));
        JLabel titleLabel = new JLabel("Wine Haven 🍷");
        titleLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        JLabel sloganLabel = new JLabel("Where Fine Wine Meets Fine Taste");
        sloganLabel.setFont(new Font("Brush Script MT", Font.ITALIC, 18));
        sloganLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        titlePanel.add(sloganLabel);
        topPanel.add(titlePanel);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(new Color(247, 231, 206));
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        searchButton.setBackground(new Color(128, 0, 0));
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(e -> updateProductPanel(searchField.getText()));
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        topPanel.add(searchPanel);

        JButton switchToAdminButton = new JButton("Switch to Admin View");
        switchToAdminButton.setBackground(new Color(247, 231, 206));
        switchToAdminButton.setForeground(Color.BLACK);
        switchToAdminButton.addActionListener(e -> switchToAdminView());
        topPanel.add(switchToAdminButton);

        add(topPanel, BorderLayout.NORTH);

        JPanel filterPanel = new JPanel(new BorderLayout());
        filterPanel.setBackground(new Color(247, 231, 206));

        JPanel filterContentPanel = new JPanel();
        filterContentPanel.setLayout(new BoxLayout(filterContentPanel, BoxLayout.Y_AXIS));
        filterContentPanel.setBackground(new Color(247, 231, 206));

        typePanel = new JPanel();
        typePanel.setLayout(new BoxLayout(typePanel, BoxLayout.Y_AXIS));
        typePanel.setBackground(new Color(247, 231, 206));
        typePanel.setBorder(new TitledBorder("Type"));
        addFilterCheckboxes(typePanel, availableTypes, "All Types");
        JScrollPane typeScrollPane = new JScrollPane(typePanel);
        typeScrollPane.setPreferredSize(new Dimension(180, 150));
        filterContentPanel.add(typeScrollPane);

        regionPanel = new JPanel();
        regionPanel.setLayout(new BoxLayout(regionPanel, BoxLayout.Y_AXIS));
        regionPanel.setBackground(new Color(247, 231, 206));
        regionPanel.setBorder(new TitledBorder("Region"));
        addFilterCheckboxes(regionPanel, availableRegions, "All Regions");
        JScrollPane regionScrollPane = new JScrollPane(regionPanel);
        regionScrollPane.setPreferredSize(new Dimension(180, 150));
        filterContentPanel.add(regionScrollPane);

        agePanel = new JPanel();
        agePanel.setLayout(new BoxLayout(agePanel, BoxLayout.Y_AXIS));
        agePanel.setBackground(new Color(247, 231, 206));
        agePanel.setBorder(new TitledBorder("Age"));
        Set<String> ageStrings = availableAges.stream().map(String::valueOf).collect(Collectors.toSet());
        addFilterCheckboxes(agePanel, ageStrings, "All Ages");
        JScrollPane ageScrollPane = new JScrollPane(agePanel);
        ageScrollPane.setPreferredSize(new Dimension(180, 150));
        filterContentPanel.add(ageScrollPane);

        filterPanel.add(filterContentPanel, BorderLayout.CENTER);

        JButton applyButton = new JButton("Apply Filters");
        applyButton.setBackground(new Color(128, 0, 0));
        applyButton.setForeground(Color.WHITE);
        applyButton.addActionListener(e -> applyFilters());
        filterPanel.add(applyButton, BorderLayout.SOUTH);

        add(filterPanel, BorderLayout.WEST);

        productPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        productPanel.setBackground(new Color(247, 231, 206));
        updateProductPanel("");
        JScrollPane galleryScrollPane = new JScrollPane(productPanel);
        galleryScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        add(galleryScrollPane, BorderLayout.CENTER);

        cartPanel = new JPanel(new BorderLayout());
        cartPanel.setBackground(new Color(247, 231, 206));

        cartItemsPanel = new JPanel();
        cartItemsPanel.setLayout(new BoxLayout(cartItemsPanel, BoxLayout.Y_AXIS));
        cartItemsPanel.setBackground(new Color(247, 231, 206));

        cartFooterPanel = new JPanel(new BorderLayout());
        cartFooterPanel.setBackground(new Color(247, 231, 206));
        totalLabel = new JLabel("Total: 0.00 EUR");
        totalLabel.setFont(new Font("Calibri", Font.PLAIN, 16));
        JButton checkoutButton = new JButton("Checkout");
        checkoutButton.setBackground(new Color(128, 0, 0));
        checkoutButton.setForeground(Color.WHITE);
        checkoutButton.addActionListener(e -> showCheckoutForm());
        JButton emptyCartButton = new JButton("Empty Cart");
        emptyCartButton.setBackground(new Color(128, 0, 0));
        emptyCartButton.setForeground(Color.WHITE);
        emptyCartButton.addActionListener(e -> emptyCart());
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(247, 231, 206));
        buttonPanel.add(emptyCartButton);
        buttonPanel.add(checkoutButton);
        cartFooterPanel.add(totalLabel, BorderLayout.NORTH);
        cartFooterPanel.add(buttonPanel, BorderLayout.SOUTH);

        cartPanel.add(cartItemsPanel, BorderLayout.CENTER);
        cartPanel.add(cartFooterPanel, BorderLayout.SOUTH);

        add(cartPanel, BorderLayout.EAST);

        setVisible(true);
    }

    // METHODS -----------------------------------------------------------------

    /* Adds checkboxes for each filter option with an "All" checkbox that controls the others */
    private void addFilterCheckboxes(JPanel panel, Set<String> options, String allLabel) {
        JCheckBox allBox = new JCheckBox(allLabel, true);
        allBox.setBackground(new Color(247, 231, 206));
        panel.add(allBox);
        allBox.addItemListener(e -> {
            boolean selectAll = allBox.isSelected();
            for (Component comp : panel.getComponents()) {
                if (comp instanceof JCheckBox && comp != allBox) {
                    ((JCheckBox) comp).setSelected(selectAll);
                }
            }
        });
        for (String option : options) {
            JCheckBox cb = new JCheckBox(option, true);
            cb.setBackground(new Color(247, 231, 206));
            cb.addItemListener(e -> {
                if (!cb.isSelected()) {
                    allBox.setSelected(false);
                } else {
                    boolean allSelected = true;
                    for (Component comp : panel.getComponents()) {
                        if (comp instanceof JCheckBox && comp != allBox) {
                            if (!((JCheckBox) comp).isSelected()) {
                                allSelected = false;
                                break;
                            }
                        }
                    }
                    if (allSelected) {
                        allBox.setSelected(true);
                    }
                }
            });
            panel.add(cb);
        }
    }

    /* Gets the currently selected filter options, ignoring the "All" checkbox */
    private List<String> getSelectedOptions(JPanel panel, String allLabel) {
        List<String> selected = new ArrayList<>();
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JCheckBox) {
                JCheckBox cb = (JCheckBox) comp;
                if (!cb.getText().equals(allLabel) && cb.isSelected()) {
                    selected.add(cb.getText());
                }
            }
        }
        return selected;
    }

    private void updateProductPanel(String keyword) {
        productPanel.removeAll();
        for (Product product : catalog.search(keyword)) {
            productPanel.add(createProductPanel((Wine) product));
        }
        productPanel.revalidate();
        productPanel.repaint();
    }

    /* Creates a product card panel with image, details and add to cart button */
    private JPanel createProductPanel(Wine wine) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.setBackground(new Color(255, 245, 230));
    
        JPanel imagePanel = new JPanel();
        imagePanel.setPreferredSize(new Dimension(100, 100));
        imagePanel.setBackground(Color.WHITE);
    
        String imagePath = "/images/white-wine.jpg";
        if ("Red".equals(wine.getWineType())) {
            imagePath = "/images/red-wine.jpg";
        } else if ("Rosé".equals(wine.getWineType())) {
            imagePath = "/images/rose-wine.jpg";
        } else if ("Sparkling".equals(wine.getWineType())) {
            imagePath = "/images/sparkling-wine.jpg";
        }
    
        try {
            Image scaledImage = new ImageIcon(getClass().getResource(imagePath)).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
            imagePanel.add(imageLabel);
        } catch (Exception e) {
            System.err.println("Error loading image: " + imagePath);
            imagePanel.add(new JLabel("No Image"));
            e.printStackTrace();
        }
    
        panel.add(imagePanel, BorderLayout.WEST);
    
        JTextArea details = new JTextArea(wine.getName() + "\n"
                + "Type: " + wine.getWineType() + "\n"
                + "Region: " + wine.getRegion() + "\n"
                + "Age: " + wine.getAge() + " years\n"
                + "Price: " + wine.getPrice() + " EUR\n"
                + "Stock: " + wine.getStock());
        details.setEditable(false);
        details.setFont(new Font("Calibri", Font.PLAIN, 14));
        panel.add(details, BorderLayout.CENTER);
    
        JButton addToCartButton = new JButton("Add to Cart");
        addToCartButton.setBackground(new Color(128, 0, 0));
        addToCartButton.setForeground(Color.WHITE);
        addToCartButton.addActionListener(e -> addToCart(wine));
        panel.add(addToCartButton, BorderLayout.SOUTH);
    
        return panel;
    }

    /* Handles adding a product to cart, updates stock in DB and refreshes UI */
    private void addToCart(Product product) {
        try {
            if (product.getStock() > 0) {
                cart.put(product, cart.getOrDefault(product, 0) + 1);
                totalAmount += product.getPrice();
                product.setStock(product.getStock() - 1);
                catalog.updateProductStockInDatabase(product);
                updateProductPanel("");
                updateCart();
            } else {
                JOptionPane.showMessageDialog(this, product.getName() + " is sold out!", "Sold Out", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            cart.put(product, cart.getOrDefault(product, 0) - 1);
            totalAmount -= product.getPrice();
            product.setStock(product.getStock() + 1);
            updateCart();
        }
    }

    private void updateCart() {
        cartItemsPanel.removeAll();
        for (Map.Entry<Product, Integer> entry : cart.entrySet()) {
            Product product = entry.getKey();
            int quantity = entry.getValue();

            JPanel cartItemPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JLabel nameLabel = new JLabel(product.getName() + " x " + quantity);
            JButton plusButton = new JButton("+");
            plusButton.setBackground(new Color(128, 0, 0));
            plusButton.setForeground(Color.WHITE);
            plusButton.addActionListener(e -> addToCart(product));
            JButton minusButton = new JButton("−");
            minusButton.setBackground(new Color(128, 0, 0));
            minusButton.setForeground(Color.WHITE);
            minusButton.addActionListener(e -> removeFromCart(product));

            cartItemPanel.add(nameLabel);
            cartItemPanel.add(plusButton);
            cartItemPanel.add(minusButton);
            cartItemsPanel.add(cartItemPanel);
        }
        totalLabel.setText("Total: " + String.format("%.2f EUR", totalAmount));
        cartItemsPanel.revalidate();
        cartItemsPanel.repaint();
    }

    private void removeFromCart(Product product) {
        try {
            if (cart.containsKey(product)) {
                int quantity = cart.get(product);
                if (quantity > 1) {
                    cart.put(product, quantity - 1);
                } else {
                    cart.remove(product);
                }
                totalAmount -= product.getPrice();
                product.setStock(product.getStock() + 1);
                catalog.updateProductStockInDatabase(product);
                updateProductPanel("");
                updateCart();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            cart.put(product, cart.getOrDefault(product, 0) + 1);
            totalAmount += product.getPrice();
            product.setStock(product.getStock() - 1);
            updateCart();
        }
    }

    /* Returns items from cart back to stock and updates both DB and UI */
    private void emptyCart() {
        if (!cart.isEmpty()) {
            for (Map.Entry<Product, Integer> entry : cart.entrySet()) {
                Product product = entry.getKey();
                int quantity = entry.getValue();
                product.setStock(product.getStock() + quantity);
                try {
                    catalog.updateProductStockInDatabase(product);
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this,
                        "Error updating stock for " + product.getName() + ": " + e.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            cart.clear();
            totalAmount = 0.0;
            updateCart();
            updateProductPanel("");
        }
    }

    private void applyFilters() {
        List<String> selectedTypes = getSelectedOptions(typePanel, "All Types");
        List<String> selectedRegions = getSelectedOptions(regionPanel, "All Regions");
        List<String> selectedAgesStr = getSelectedOptions(agePanel, "All Ages");
        List<Integer> selectedAges = selectedAgesStr.stream().map(Integer::parseInt).collect(Collectors.toList());
        List<Product> filteredProducts = catalog.search("");
        if (!selectedTypes.isEmpty()) {
            filteredProducts = filteredProducts.stream()
                    .filter(p -> p instanceof Wine && selectedTypes.contains(((Wine) p).getWineType()))
                    .collect(Collectors.toList());
        }
        if (!selectedRegions.isEmpty()) {
            filteredProducts = filteredProducts.stream()
                    .filter(p -> p instanceof Wine && selectedRegions.stream().anyMatch(r -> ((Wine) p).getRegion().toLowerCase().contains(r.toLowerCase())))
                    .collect(Collectors.toList());
        }
        if (!selectedAges.isEmpty()) {
            filteredProducts = filteredProducts.stream()
                    .filter(p -> p instanceof Wine && selectedAges.contains(((Wine) p).getAge()))
                    .collect(Collectors.toList());
        }
        productPanel.removeAll();
        for (Product product : filteredProducts) {
            productPanel.add(createProductPanel((Wine) product));
        }
        productPanel.revalidate();
        productPanel.repaint();
    }

    /* Shows checkout form, saves order to DB and displays confirmation */
    private void showCheckoutForm() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your cart is empty. Please add products before checkout.", "Empty Cart", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JPanel checkoutPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        checkoutPanel.setBackground(new Color(247, 231, 206));
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField instructionsField = new JTextField();
        checkoutPanel.add(new JLabel("Name*"));
        checkoutPanel.add(nameField);
        checkoutPanel.add(new JLabel("Email*"));
        checkoutPanel.add(emailField);
        checkoutPanel.add(new JLabel("Phone*"));
        checkoutPanel.add(phoneField);
        checkoutPanel.add(new JLabel("Address*"));
        checkoutPanel.add(addressField);
        checkoutPanel.add(new JLabel("Specific Instructions"));
        checkoutPanel.add(instructionsField);
        int option = JOptionPane.showConfirmDialog(this, checkoutPanel, "Enter Delivery Details", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            if (nameField.getText().isEmpty() || emailField.getText().isEmpty() ||
                phoneField.getText().isEmpty() || addressField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all the required fields marked with *", "Error", JOptionPane.ERROR_MESSAGE);
                showCheckoutForm();
            } else {
                Customer customer = new Customer(nameField.getText(), emailField.getText(), phoneField.getText(), addressField.getText());
                try {
                    customer.saveToDatabase();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error saving customer to database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                    e.printStackTrace();
                    return;
                }

                Order order = new Order(customer, cart, totalAmount);
                try {
                    order.saveToDatabase();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error saving order to database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                    e.printStackTrace();
                    return;
                }

                Invoice invoice = new Invoice(order);
                try {
                    invoice.saveToDatabase();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error saving invoice to database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                    e.printStackTrace();
                    return;
                }

                StringBuilder orderSummary = new StringBuilder("Thank you for your order, " + nameField.getText() + "!\n\n");
                orderSummary.append("Items Ordered:\n");
                for (Map.Entry<Product, Integer> entry : cart.entrySet()) {
                    orderSummary.append(entry.getKey().getName()).append(" x ").append(entry.getValue()).append("\n");
                }
                orderSummary.append("\nTotal: ").append(String.format("%.2f", totalAmount)).append(" EUR\n\n");
                orderSummary.append("Deliver to: ").append(addressField.getText()).append("\n");
                orderSummary.append("Specific Instructions: ").append(instructionsField.getText()).append("\n\n");
                orderSummary.append("Confirmation email was sent to ").append(emailField.getText()).append(" with your receipt.");
                JOptionPane.showMessageDialog(this, orderSummary.toString(), "Order Confirmation", JOptionPane.INFORMATION_MESSAGE);
                cart.clear();
                totalAmount = 0.0;
                updateCart();
            }
        }
    }

    private void switchToAdminView() {
        this.dispose();
        SwingUtilities.invokeLater(AdminInterface::new);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(UserInterface::new);
    }
}