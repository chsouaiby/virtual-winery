import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Order {

    // ATTRIBUTES -----------------------------------------------------------------

    private int id;
    private Customer customer;
    private Map<Product, Integer> products; // Map of products and quantities
    private double totalAmount;
    private String status;

    // CONSTRUCTORS ---------------------------------------------------------------

    public Order(Customer customer, Map<Product, Integer> products, double totalAmount) {
        this.customer = customer;
        this.products = products;
        this.totalAmount = totalAmount;
        this.status = "in progress"; // initial status
    }

    // Constructor for loading from DB
    public Order(int id, Customer customer, Map<Product, Integer> products, double totalAmount, String status) {
        this.id = id;
        this.customer = customer;
        this.products = products;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    // GETTERS + SETTERS -----------------------------------------------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Map<Product, Integer> getProducts() {
        return products;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if (isValidStatus(status)) {
            this.status = status;
        } else {
            throw new IllegalArgumentException("Invalid order status: " + status);
        }
    }

    // METHODS ------------------------------------------------------------------

    private boolean isValidStatus(String status) {
        return status != null && (
                status.equalsIgnoreCase("in progress") ||
                status.equalsIgnoreCase("validated") ||
                status.equalsIgnoreCase("delivered"));
    }

    
    public void saveToDatabase() throws SQLException {

        /* This method gathers the properties of the object we want to add, and runs an SQL query to save them directly on the Database. */

        String orderQuery = "INSERT INTO orders (customer_id, total_amount, status) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, customer.getId());
            stmt.setDouble(2, totalAmount);
            stmt.setString(3, status);
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int orderId = rs.getInt(1);
                this.id = orderId;

                String itemQuery = "INSERT INTO order_items (order_id, wine_id, quantity) VALUES (?, ?, ?)";
                try (PreparedStatement itemStmt = connection.prepareStatement(itemQuery)) {
                    for (Map.Entry<Product, Integer> entry : products.entrySet()) {
                        itemStmt.setInt(1, orderId);
                        itemStmt.setInt(2, entry.getKey().getId());
                        itemStmt.setInt(3, entry.getValue());
                        itemStmt.executeUpdate();
                    }
                }
            }
        }
    }


    public static List<Order> loadAllOrders() throws SQLException {

        /* This method runs a query to retrieve all the entries we have in the table and create an object out of each  */

        List<Order> orders = new ArrayList<>();
        String orderQuery = "SELECT * FROM orders";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(orderQuery)) {

            while (rs.next()) {
                int orderId = rs.getInt("id");
                int customerId = rs.getInt("customer_id");
                double total = rs.getDouble("total_amount");
                String status = rs.getString("status");
                Customer customer = Customer.loadById(customerId);
                Map<Product, Integer> items = loadOrderItems(connection, orderId);

                orders.add(new Order(orderId, customer, items, total, status));
            }
        }
        return orders;
    }

    public static Order loadById(int orderId) throws SQLException {

        /* This method runs a query to retrieve a specific entry in the table and create an object out of it  */ 

        String orderQuery = "SELECT * FROM orders WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(orderQuery)) {
            stmt.setInt(1, orderId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int customerId = rs.getInt("customer_id");
                    double total = rs.getDouble("total_amount");
                    String status = rs.getString("status");
                    Customer customer = Customer.loadById(customerId);
                    Map<Product, Integer> items = loadOrderItems(connection, orderId);

                    return new Order(orderId, customer, items, total, status);
                }
            }
        }
        return null;
    }

    // Load order items
    private static Map<Product, Integer> loadOrderItems(Connection connection, int orderId) throws SQLException {

        /* This method runs a query to retrieve all the entries we have in the table and update the objects referenced by them  */

        Map<Product, Integer> items = new HashMap<>();
        String itemQuery = "SELECT * FROM order_items WHERE order_id = ?";
        try (PreparedStatement itemStmt = connection.prepareStatement(itemQuery)) {
            itemStmt.setInt(1, orderId);
            try (ResultSet itemRs = itemStmt.executeQuery()) {
                while (itemRs.next()) {
                    int wineId = itemRs.getInt("wine_id");
                    int quantity = itemRs.getInt("quantity");
                    Product product = Wine.loadById(wineId);
                    if (product != null) {
                        items.put(product, quantity);
                    }
                }
            }
        }
        return items;
    }

    
    public static void updateOrderStatus(int orderId, String newStatus) throws SQLException {

        /* This method updates information about a specific object and in its equivalent entry in the table */ 

        if (!newStatus.equalsIgnoreCase("validated") && !newStatus.equalsIgnoreCase("delivered") && !newStatus.equalsIgnoreCase("in progress")) {
            throw new IllegalArgumentException("Invalid status: " + newStatus);
        }

        String sql = "UPDATE orders SET status = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, newStatus);
            stmt.setInt(2, orderId);
            stmt.executeUpdate();
        }
    }

    public static void deleteOrder(int orderId) throws SQLException {

        /* deletes an object and its associated entries from the table it is in and the ones referencing it */ 

        try (Connection connection = DatabaseConnection.getConnection()) {
            connection.setAutoCommit(false);

            // Delete order items first
            String deleteItemsQuery = "DELETE FROM order_items WHERE order_id = ?";
            try (PreparedStatement itemStmt = connection.prepareStatement(deleteItemsQuery)) {
                itemStmt.setInt(1, orderId);
                itemStmt.executeUpdate();
            }

            // Delete the order
            String deleteOrderQuery = "DELETE FROM orders WHERE id = ?";
            try (PreparedStatement orderStmt = connection.prepareStatement(deleteOrderQuery)) {
                orderStmt.setInt(1, orderId);
                orderStmt.executeUpdate();
            }

            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error deleting order: " + e.getMessage());
        }
    }
}
