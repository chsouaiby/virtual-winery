import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Invoice {

    // ATTRIBUTES -----------------------------------------------------------------

    private int id;
    private Order order; 
    private double total;
    private double taxRate;

    // CONSTRUCTORS -----------------------------------------------------------------

    public Invoice() {} // For database loading

    public Invoice(Order order) { 
        this.order = order;
        this.total = calculateTotal();
        this.taxRate = 0.19; // tax rate by default
    }

    public Invoice(int id, Order order, double total, double taxRate) {
        this.id = id;
        this.order = order;
        this.total = total;
        this.taxRate = taxRate;
    }

    // GETTERS + SETTERS ---------------------------------------------------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    // METHODS ----------------------------------------------------------------------

    private double calculateTotal() { //applying the percentage of tax on the order total price
        double orderTotal = order.getTotalAmount();
        return orderTotal * (1 + taxRate);
    }

    public void saveToDatabase() throws SQLException {

        /* This method gathers the properties of the object we want to add, and runs an SQL query to save them directly on the Database  */

        Connection connection = DatabaseConnection.getConnection();
        String sql;

        if (id == 0) { // New Invoice
            sql = "INSERT INTO invoices (order_id, total, tax_rate) VALUES (?, ?, ?)";
        } else { // Existing Invoice
            sql = "UPDATE invoices SET order_id = ?, total = ?, tax_rate = ? WHERE id = ?";
        }

        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, order.getId());
            statement.setDouble(2, total);
            statement.setDouble(3, taxRate);

            if (id != 0) { //puts the ID of the existing invoice in the query
                statement.setInt(4, id);
            }

            statement.executeUpdate();

            if (id == 0) { // Retrieve ID for new invoice
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        id = generatedKeys.getInt(1);
                    }
                }
            }
        }
    }

    public static List<Invoice> loadAllInvoices() throws SQLException {

        /* This method runs a query to retrieve all the entries we have in the table and create an object out of each  */ 

        List<Invoice> invoices = new ArrayList<>();
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM invoices";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                int orderId = resultSet.getInt("order_id");
                Order order = Order.loadById(orderId); // accessing the order by the key(order id) referencing it
                Invoice invoice = new Invoice(
                        resultSet.getInt("id"),
                        order,
                        resultSet.getDouble("total"),
                        resultSet.getDouble("tax_rate"));
                invoices.add(invoice);
            }
        }
        return invoices;
    }


    public static void deleteInvoice(int invoiceId) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM invoices WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            statement.executeUpdate();
        }
    }


}