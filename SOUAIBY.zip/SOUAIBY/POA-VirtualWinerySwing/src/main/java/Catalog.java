import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Catalog {

    // ATTRIBUTES -----------------------------------------------------------------

    private List<Product> products;

    // CONSTRUCTORS ---------------------------------------------------------------

    public Catalog() {
        products = new ArrayList<>();
    }

    // METHODS --------------------------------------------------------------------

    public void addProduct(Product product) {
        products.add(product);
    }

    public List<Product> search(String keyword) {
        List<Product> results = new ArrayList<>();
        if (keyword == null || keyword.trim().isEmpty()) {
            return new ArrayList<>(products);
        }
        String cleanKeyword = keyword.trim().toLowerCase();
        for (Product product : products) {
            if (product.getName().toLowerCase().contains(cleanKeyword)) {
                results.add(product);
            }
        }
        return results;
    }

    public Product findByName(String name) {
        for (Product product : products) {
            if (product.getName().equalsIgnoreCase(name)) {
                return product;
            }
        }
        return null;
    }

    public void loadProductsFromDatabase() throws SQLException {
        products.clear(); // Clear existing products

        try (Connection connection = DatabaseConnection.getConnection()) {
            List<? extends Product> loadedProducts = new Wine().loadAllProducts(connection);
            products.addAll(loadedProducts);
        }
    }

    public void updateProductStockInDatabase(Product product) throws SQLException { 
        if (product != null) {
            product.updateStock(product.getStock()); 
        }
    }

    public void addOrderToDatabase(Order order) throws SQLException {
        order.saveToDatabase();
    }

    public void deleteProduct(int productId) throws SQLException {
        Product product = getProductById(productId);
        if (product != null) {
            product.delete();
        }
        loadProductsFromDatabase(); // Refresh after deletion
    }

    public Product getProductById(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null;
    }

    public void saveProductToDatabase(Product product) throws SQLException {
        product.saveToDatabase();
        loadProductsFromDatabase(); // Refresh after saving
    }
}