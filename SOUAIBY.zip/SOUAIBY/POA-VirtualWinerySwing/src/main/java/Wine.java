import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Wine extends Product {

    // ATTRIBUTES ---------------------------------------------------------------

    private String wineType;
    private String region;
    private int age;

    // CONSTRUCTORS ---------------------------------------------------------------

    public Wine() {} // Needed for database loading

    public Wine(int id, String name, double price, int stock, String wineType, String region, int age) {
        super(id, name, price, stock);
        this.wineType = wineType;
        this.region = region;
        this.age = age;
    }

    public Wine(String name, double price, int stock, String wineType, String region, int age) {
        super(name, price, stock);
        this.wineType = wineType;
        this.region = region;
        this.age = age;
    }

    // GETTERS AND SETTERS ---------------------------------------------------------------

    public String getWineType() {
        return wineType;
    }

    public void setWineType(String wineType) {
        this.wineType = wineType;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // METHODS ---------------------------------------------------------------

    public void restock(int amount) throws SQLException { 

        /* restocks the wine by a given amount by adding it to the current stock, and updates the associated entry in the database */

        if (amount <= 0) {
            throw new IllegalArgumentException("Restock amount must be greater than zero.");
        }

        this.stock += amount; // Update object stock

        String sql = "UPDATE wines SET stock = stock + ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, amount);
            stmt.setInt(2, this.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void delete() throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM wines WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, this.getId());
            statement.executeUpdate();
        }
    }

    @Override
    public void saveToDatabase() throws SQLException {

        /* This method gathers the properties of the object we want to add, and runs an SQL query to save them directly on the Database. 
        Some print statements are here for debugging purposes */ 

        Connection connection = DatabaseConnection.getConnection();
        String sql;

        if (this.id == 0) { // NEW WINE (INSERT)
            sql = "INSERT INTO wines (name, price, stock, type, region, age) VALUES (?, ?, ?, ?, ?, ?)";
        } else { // EXISTING WINE (UPDATE)
            sql = "UPDATE wines SET name = ?, price = ?, stock = ?, type = ?, region = ?, age = ? WHERE id = ?";
        }

        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, name);
            statement.setDouble(2, price);
            statement.setInt(3, stock);
            statement.setString(4, wineType);
            statement.setString(5, region);
            statement.setInt(6, age);

            if (this.id != 0) { // If updating, set ID
                statement.setInt(7, this.id);
            }

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("ERROR: Wine save failed, no rows affected.");
            }

            // Only retrieve ID if it's a new record
            if (this.id == 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        this.id = generatedKeys.getInt(1); // 
                        System.out.println(" Wine added with ID: " + this.id);
                    } else {
                        throw new SQLException("ERROR: No ID obtained.");
                    }
                }
            }
        }
    }


    public static Wine loadById(int id) throws SQLException {

        /* This method runs a query to retrieve a specific entry in the table and create an object out of it  */ 

        String query = "SELECT * FROM wines WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String name = rs.getString("name");
                    double price = rs.getDouble("price");
                    int stock = rs.getInt("stock");
                    String wineType = rs.getString("type");
                    String region = rs.getString("region");
                    int age = rs.getInt("age");
                    return new Wine(id, name, price, stock, wineType, region, age);
                }
            }
        }
        return null;
    }

    @Override
    public List<Wine> loadAllProducts(Connection connection) throws SQLException {

        /* This method runs a query to retrieve all the entries we have in the table and create an object out of each  */ 

        List<Wine> wines = new ArrayList<>();
        String sql = "SELECT * FROM wines";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Wine wine = new Wine(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price"),
                        resultSet.getInt("stock"),
                        resultSet.getString("type"),
                        resultSet.getString("region"),
                        resultSet.getInt("age"));
                wines.add(wine);
            }
        }
        return wines;
    }

    @Override
    public void updateStock(int newStock) throws SQLException {

        /* This method runs a query to update a certain object and its equivalent existing entry in the table  */ 

        Connection connection = DatabaseConnection.getConnection();
        String sql = "UPDATE wines SET stock = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, newStock);
            statement.setInt(2, this.getId());
            statement.executeUpdate();
            this.setStock(newStock);
        }
    }

    @Override
    public String toString() {
        return name + " - " + wineType + " - " + region + " - Age: " + age + " years - Price: " + price + " EUR";
    }
}
