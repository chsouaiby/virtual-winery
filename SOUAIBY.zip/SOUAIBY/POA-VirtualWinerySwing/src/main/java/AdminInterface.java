import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.List;

import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

public class AdminInterface extends JFrame {

    /* AdminInterface serves as the control panel for managing customers, wines, orders, and invoices.
     it allows the admin to perform CRUD operations for each entity.
     Check the user.pdf document for more details on how this interface works.*/ 

    // ATTRIBUTES -----------------------------------------------------------------
    private JTable customerTable, wineTable, orderTable, invoiceTable;
    private Catalog catalog;

    // CONSTRUCTORS ---------------------------------------------------------------

    public AdminInterface() {
        catalog = new Catalog();
        setTitle("Admin Dashboard");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel with "Switch to User View" Button
        JPanel topPanel = new JPanel(new FlowLayout());
        JButton switchToUserButton = createButton("Switch to User View", this::switchToUserView);
        topPanel.add(switchToUserButton);
        add(topPanel, BorderLayout.NORTH);

        // Center Tabbed Pane for Customers, Wines, Orders, Invoices
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.add("Customers", createCustomerPanel());
        tabbedPane.add("Wines", createWinePanel());
        tabbedPane.add("Orders", createOrderPanel());
        tabbedPane.add("Invoices", createInvoicePanel());
        add(tabbedPane, BorderLayout.CENTER);

        setVisible(true);
    }

    // CLASSES -----------------------------------------------------------------

    // ------------------ Custom Component Renderer & Editor ------------------
    class ComponentCellRenderer implements TableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof Component) {
                return (Component) value;
            }
            return new JLabel(value == null ? "" : value.toString());
        }
    }

    class ComponentCellEditor extends AbstractCellEditor implements TableCellEditor {
        private Component component;
        @Override
        public Object getCellEditorValue() {
            return component;
        }
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                                                       boolean isSelected, int row, int column) {
            if (value instanceof Component) {
                component = (Component) value;
                return component;
            }
            return new JLabel(value == null ? "" : value.toString());
        }
    }

    // METHODS -----------------------------------------------------------------

    // ------------------ Helper Methods for Buttons ------------------
    private JButton createButton(String text, Runnable action) {
        JButton button = new JButton(text);
        button.setBackground(new Color(128, 0, 0)); // Burgundy
        button.setForeground(Color.WHITE);
        button.addActionListener(e -> action.run());
        return button;
    }

    private JPanel createDeleteButton(Runnable action) {
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(createButton("Delete", action));
        return panel;
    }

    // ------------------ Customers Panel ------------------
    private JPanel createCustomerPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        customerTable = new JTable();
        customerTable.setRowHeight(50);
        try {
            loadCustomers();
        } catch (SQLException e) {
            showError("Error loading customers", e);
        }
        customerTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        customerTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
        panel.add(new JScrollPane(customerTable), BorderLayout.CENTER);
        return panel;
    }

    private void loadCustomers() throws SQLException {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID", "Name", "Email", "Phone", "Address", "Actions"}, 0);
        List<Customer> customers = Customer.loadAllCustomers();
        
        for (Customer c : customers) {
            JPanel actionPanel = new JPanel(new FlowLayout());
            JButton editButton = createButton("Edit", () -> editCustomer(c));
            JButton deleteButton = createButton("Delete", () -> deleteCustomer(c.getId()));
            actionPanel.add(editButton);
            actionPanel.add(deleteButton);
            
            model.addRow(new Object[]{c.getId(), c.getName(), c.getEmail(), c.getPhone(), c.getAddress(), actionPanel});
        }
    
        customerTable.setModel(model);
    
        // **Reapply Button Renderers & Editors to Preserve Functionality**
        customerTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        customerTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
    }
    

    private void editCustomer(Customer customer) {
        JTextField nameField = new JTextField(customer.getName());
        JTextField emailField = new JTextField(customer.getEmail());
        JTextField phoneField = new JTextField(customer.getPhone());
        JTextField addressField = new JTextField(customer.getAddress());
    
        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Phone:"));
        panel.add(phoneField);
        panel.add(new JLabel("Address:"));
        panel.add(addressField);
    
        int result = JOptionPane.showConfirmDialog(this, panel, "Edit Customer", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                customer.setName(nameField.getText());
                customer.setEmail(emailField.getText());
                customer.setPhone(phoneField.getText());
                customer.setAddress(addressField.getText());
                customer.saveToDatabase(); // Save changes
    
                loadCustomers();
            } catch (SQLException e) {
                showError("Error updating customer", e);
            }
        }
    }
    

    private void deleteCustomer(int customerId) {
        int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this customer? This will also delete their orders and invoices.",
                "Delete Customer", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            try {
                Customer.delete(customerId);
                loadCustomers();
                loadOrders();
                loadInvoices();
            } catch (SQLException e) {
                showError("Error deleting customer", e);
            }
        }
    }

    // ------------------ Wines Panel ------------------
    private JPanel createWinePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        // Add Wine Button at the Top
        JPanel topPanel = new JPanel(new FlowLayout());
        JButton addWineButton = createButton("Add Wine", this::showAddWineDialog);
        topPanel.add(addWineButton);
        panel.add(topPanel, BorderLayout.NORTH);
        // Wine Table
        wineTable = new JTable();
        wineTable.setRowHeight(50);
        try {
            loadWines();
        } catch (SQLException e) {
            showError("Error loading wines", e);
        }
        wineTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        wineTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
        panel.add(new JScrollPane(wineTable), BorderLayout.CENTER);
        return panel;
    }

    private void showAddWineDialog() {
        JPanel panel = new JPanel(new GridLayout(6, 2));
        JTextField nameField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField stockField = new JTextField();
        JTextField typeField = new JTextField();
        JTextField regionField = new JTextField();
        JTextField yearField = new JTextField(); // Year corresponds to "age" in Wine
    
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Price:"));
        panel.add(priceField);
        panel.add(new JLabel("Stock:"));
        panel.add(stockField);
        panel.add(new JLabel("Type:"));
        panel.add(typeField);
        panel.add(new JLabel("Region:"));
        panel.add(regionField);
        panel.add(new JLabel("Year:"));
        panel.add(yearField);
    
        int result = JOptionPane.showConfirmDialog(this, panel, "Add New Wine", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());
                int stock = Integer.parseInt(stockField.getText());
                String type = typeField.getText();
                String region = regionField.getText();
                int year = Integer.parseInt(yearField.getText());
    
                Wine newWine = new Wine(name, price, stock, type, region, year);
                
                // Debugging Output: Print the wine details before saving
                System.out.println("Attempting to save wine: " + newWine);
    
                newWine.saveToDatabase(); // Save to DB
                catalog.loadProductsFromDatabase(); // Refresh catalog
                loadWines(); // Update UI table
    
                JOptionPane.showMessageDialog(this, "✅ Wine added successfully!");
            } catch (NumberFormatException | SQLException e) {
                showError("❌ Error adding wine", e);
            }
        }
    }
    

    private void loadWines() throws SQLException {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID", "Name", "Price", "Stock", "Type", "Region", "Year", "Actions"}, 0);
        catalog.loadProductsFromDatabase();
        for (Product p : catalog.search("")) {
            if (p instanceof Wine) {
                Wine w = (Wine) p;
                JPanel actionPanel = new JPanel(new FlowLayout());
                actionPanel.add(createButton("Restock", () -> restockWine(w.getId())));
                actionPanel.add(createDeleteButton(() -> deleteWine(w.getId())));
                model.addRow(new Object[]{w.getId(), w.getName(), w.getPrice(), w.getStock(),
                        w.getWineType(), w.getRegion(), w.getAge(), actionPanel});
            }
        }
        wineTable.setModel(model);
        wineTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        wineTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
    }

    private void restockWine(int wineId) {
        String input = JOptionPane.showInputDialog(this, "Enter restock amount:");
        if (input != null) {
            try {
                int amount = Integer.parseInt(input);
                Wine wine = Wine.loadById(wineId);
                if (wine != null) {
                    wine.restock(amount);
                    loadWines();
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid number!", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException e) {
                showError("Error during restock", e);
            }
        }
    }

    private void deleteWine(int wineId) {
        int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this wine?",
                "Delete Wine", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            try {
                catalog.deleteProduct(wineId);
                loadWines();
            } catch (SQLException e) {
                showError("Error deleting wine", e);
            }
        }
    }

    // ------------------ Orders Panel ------------------
    private JPanel createOrderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        orderTable = new JTable();
        orderTable.setRowHeight(50);
        try {
            loadOrders();
        } catch (SQLException e) {
            showError("Error loading orders", e);
        }
        orderTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        orderTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
        panel.add(new JScrollPane(orderTable), BorderLayout.CENTER);
        return panel;
    }

    private void loadOrders() throws SQLException {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID", "Customer ID", "Total", "Status", "Actions"}, 0);
        List<Order> orders = Order.loadAllOrders();
        for (Order o : orders) {
            JPanel actionPanel = new JPanel(new FlowLayout());
            actionPanel.add(createButton("Update Status", () -> updateOrderStatus(o.getId())));
            actionPanel.add(createDeleteButton(() -> deleteOrder(o.getId())));
            model.addRow(new Object[]{o.getId(), o.getCustomer().getId(), o.getTotalAmount(), o.getStatus(), actionPanel});
        }
        orderTable.setModel(model);
        orderTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        orderTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
    }

    private void updateOrderStatus(int orderId) {
        String[] statuses = {"In Progress", "Validated", "Delivered"};
        String newStatus = (String) JOptionPane.showInputDialog(this, "Select new status:",
                "Update Order Status", JOptionPane.PLAIN_MESSAGE, null, statuses, statuses[0]);
        if (newStatus != null) {
            try {
                Order.updateOrderStatus(orderId, newStatus);
                if ("Validated".equalsIgnoreCase(newStatus)) {
                    generateInvoice(orderId);
                }
                loadOrders();
            } catch (SQLException e) {
                showError("Error updating order status", e);
            }
        }
    }

    private void deleteOrder(int orderId) {
        int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this order?",
                "Delete Order", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            try {
                Order.deleteOrder(orderId);
                loadOrders();
                loadInvoices();
            } catch (SQLException e) {
                showError("Error deleting order", e);
            }
        }
    }

    // ------------------ Invoices Panel ------------------
    private JPanel createInvoicePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        invoiceTable = new JTable();
        invoiceTable.setRowHeight(50);
        try {
            loadInvoices();
        } catch (SQLException e) {
            showError("Error loading invoices", e);
        }
        invoiceTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        invoiceTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
        panel.add(new JScrollPane(invoiceTable), BorderLayout.CENTER);
        return panel;
    }

    private void loadInvoices() throws SQLException {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID", "Order ID", "Total", "Actions"}, 0);
        List<Invoice> invoices = Invoice.loadAllInvoices();
        for (Invoice i : invoices) {
            JPanel actionPanel = new JPanel(new FlowLayout());
            actionPanel.add(createDeleteButton(() -> {
                int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this invoice?",
                        "Delete Invoice", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    try {
                        Invoice.deleteInvoice(i.getId());
                        loadInvoices();
                    } catch (SQLException e) {
                        showError("Error deleting invoice", e);
                    }
                }
            }));
            model.addRow(new Object[]{i.getId(), i.getOrder().getId(), i.getTotal(), actionPanel});
        }
        invoiceTable.setModel(model);
        invoiceTable.getColumn("Actions").setCellRenderer(new ComponentCellRenderer());
        invoiceTable.getColumn("Actions").setCellEditor(new ComponentCellEditor());
    }

    // ------------------ Invoice Generation ------------------
    private void generateInvoice(int orderId) {
        try {
            Order order = Order.loadById(orderId);
            Invoice invoice = new Invoice(order);
            invoice.saveToDatabase();
            JOptionPane.showMessageDialog(this, "Invoice generated for order " + orderId,
                    "Invoice", JOptionPane.INFORMATION_MESSAGE);
            loadInvoices();
        } catch (SQLException e) {
            showError("Error generating invoice", e);
        }
    }

    // ------------------ Switch to User View ------------------
    private void switchToUserView() {
        this.dispose();
        SwingUtilities.invokeLater(UserInterface::new);
    }

    // ------------------ Error Handling ------------------
    private void showError(String message, Exception e) {
        JOptionPane.showMessageDialog(this, message + ": " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }

    // ------------------ Main Method ------------------
    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminInterface::new);
    }
}