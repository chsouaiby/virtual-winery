import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StartFrame extends JFrame {

    // CONSTRUCTORS -----------------------------------------------------------------

    public StartFrame() {
        setTitle("Wine Haven");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(128, 0, 0)); // Burgundy background
        setLayout(new BorderLayout());

        // Center panel with title, slogan, and wine cup emoji
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(new Color(128, 0, 0));

        JLabel titleLabel = new JLabel("Wine Haven", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel emojiLabel = new JLabel("🍷", SwingConstants.CENTER);
        emojiLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD, 48));
        emojiLabel.setForeground(Color.WHITE);
        emojiLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sloganLabel = new JLabel("Where Fine Wine Meets Fine Taste", SwingConstants.CENTER);
        sloganLabel.setFont(new Font("Brush Script MT", Font.ITALIC, 24));
        sloganLabel.setForeground(Color.WHITE);
        sloganLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(titleLabel);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(emojiLabel);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(sloganLabel);
        centerPanel.add(Box.createVerticalStrut(20));

        add(centerPanel, BorderLayout.CENTER);

        // Button panel at the bottom
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(128, 0, 0));

        JButton adminButton = new JButton("View as Admin");
        JButton userButton = new JButton("View as User");

        adminButton.setBackground(Color.WHITE);
        adminButton.setForeground(new Color(128, 0, 0));
        userButton.setBackground(Color.WHITE);
        userButton.setForeground(new Color(128, 0, 0));

        // Open Admin Interface when clicked
        adminButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new AdminInterface().setVisible(true));
                dispose(); // Close splash screen
            }
        });

        // Open User Interface when clicked
        userButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new UserInterface().setVisible(true));
                dispose(); // Close splash screen
            }
        });

        buttonPanel.add(adminButton);
        buttonPanel.add(userButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StartFrame().setVisible(true);
        });
    }
}