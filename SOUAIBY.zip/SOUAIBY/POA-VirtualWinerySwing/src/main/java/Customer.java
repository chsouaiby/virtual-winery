import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Customer {

    // ATTRIBUTES -----------------------------------------------------------------

    private int id;
    private String name;
    private String email;
    private String phone;
    private String address;

    // CONSTRUCTORS -----------------------------------------------------------------

    public Customer() {} // For database loading

    public Customer(String name, String email, String phone, String address) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    public Customer(int id, String name, String email, String phone, String address) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    // GETTERS + SETTERS ---------------------------------------------------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // METHODS ----------------------------------------------------------------------

    public void saveToDatabase() throws SQLException {

        /* Saves the customer object into the database (either inserts or updates it) */

        Connection connection = DatabaseConnection.getConnection();
        String sql;
        
        if (id == 0) { // New Customer
            sql = "INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)";
        } else { // Existing Customer
            sql = "UPDATE customers SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?";
        }

        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phone);
            statement.setString(4, address);
            if (id != 0) { // Adds ID for updates
                statement.setInt(5, id);
            }
            statement.executeUpdate();

            if (id == 0) { // Retrieve ID for new customer
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        this.id = generatedKeys.getInt(1);
                    }
                }
            }
        }
    }

    public static void delete(int id) throws SQLException {
        /* Deletes a customer from the database using its ID */
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM customers WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public static Customer loadById(int id) throws SQLException {

        /* Retrieves a single customer from the database using their ID */

        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM customers WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Customer(
                            resultSet.getInt("id"),
                            resultSet.getString("name"),
                            resultSet.getString("email"),
                            resultSet.getString("phone"),
                            resultSet.getString("address"));
                }
            }
        }
        return null; 
    }

    public static List<Customer> loadAllCustomers() throws SQLException {

        /* Retrieves all customers from the database and creates objects for each */

        List<Customer> customers = new ArrayList<>();
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM customers";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                Customer customer = new Customer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("email"),
                        resultSet.getString("phone"),
                        resultSet.getString("address"));
                customers.add(customer);
            }
        }
        return customers;
    }
}
